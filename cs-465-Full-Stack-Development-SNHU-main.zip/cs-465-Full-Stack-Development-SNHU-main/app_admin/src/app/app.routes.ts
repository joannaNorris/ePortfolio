import { Routes } from '@angular/router';
import { AddTrip } from './add-trip/add-trip';
import { TripListing } from './trip-listing/trip-listing';
import { EditTrip } from './edit-trip/edit-trip';
import { Login } from './login/login';

export const routes: Routes = [
    { path: '', component: TripListing, pathMatch: 'full' },
    { path: 'add-trip', component: AddTrip },
    { path: 'edit-trip/:code', component: EditTrip },
    { path: 'login', component: Login }
];
